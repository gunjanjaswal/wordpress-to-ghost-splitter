# WordPress to Ghost XML Splitter

![WordPress to Ghost](https://img.shields.io/badge/WordPress-Ghost-738A94?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-green.svg)

A tool to split large WordPress XML exports into smaller chunks for Ghost import. Solves the "Your file has too many posts" error when migrating from WordPress to Ghost.

<p align="center">
  <img src="https://wordpress.org/wp-content/themes/pub/wporg/images/wordpress-logo-notext-rgb.png" alt="WordPress Logo" width="100" />
  <span style="font-size: 24px; margin: 0 20px;">→</span>
  <img src="https://ghost.org/images/logos/ghost-logo-orb.png" alt="Ghost Logo" width="100" />
</p>

## 🚀 Features

- **Web Interface**: User-friendly interface for uploading and splitting WordPress XML exports
- **Command Line**: Python and PowerShell scripts for automation and batch processing
- **Content Analysis**: View detailed breakdown of your WordPress content
- **Custom Splitting**: Control chunk size and content types to include
- **Metadata Preservation**: Maintains all necessary XML headers and namespaces
- **Ghost-Ready**: Creates files optimized for Ghost import

## 🔥 The Problem

Ghost has a limitation on the number of posts that can be imported at once. When trying to import a WordPress XML export with many posts (3000+), Ghost returns the error:

> "Your file has too many posts, try a file with less posts"

## 💡 The Solution

This tool splits your WordPress XML export file into smaller chunks that can be imported into Ghost without hitting the size limitation.

## 🖥️ Web Interface (Easiest Method)

### Requirements
- Python 3.6 or higher
- Flask (installed via requirements.txt)

### Setup

```bash
# Install dependencies
pip install -r requirements.txt

# Run the web application
python app.py
```

Then open your browser to http://127.0.0.1:5000

### Using the Web Interface

1. **Upload**: Upload your WordPress XML export file
2. **Analyze**: Review the content analysis
3. **Configure**: Set chunk size and content types
4. **Split**: Process the file
5. **Download**: Get a ZIP with all split files

## 🐍 Python Command Line

### Requirements
- Python 3.6 or higher

### Usage

```bash
python wp_xml_splitter.py your_wordpress_export.xml
```

### Options

```
  -h, --help            Show help message
  -o OUTPUT_DIR, --output-dir OUTPUT_DIR
                        Directory to save split files (default: "split_output")
  -s CHUNK_SIZE, --chunk-size CHUNK_SIZE
                        Maximum items per chunk (default: 100)
  -t POST_TYPES [POST_TYPES ...], --post-types POST_TYPES [POST_TYPES ...]
                        Post types to include (e.g., post page attachment)
  -c, --count-only      Only count items, don't split
```

### Examples

```bash
# Count items in WordPress export
python wp_xml_splitter.py your_wordpress_export.xml -c

# Split into chunks of 50 posts
python wp_xml_splitter.py your_wordpress_export.xml -s 50

# Only include posts and pages
python wp_xml_splitter.py your_wordpress_export.xml -t post page
```

## 💻 PowerShell (Windows Only)

### Requirements
- Windows with PowerShell

### Usage

```powershell
.\Split-WordPressXML.ps1 -InputFile "path\to\your_wordpress_export.xml"
```

### Options

```
  -InputFile         Path to WordPress XML export file (required)
  -OutputDir         Directory to save split files (default: "split_output")
  -ChunkSize         Maximum items per chunk (default: 100)
  -CountOnly         Only count items, don't split
```

### Examples

```powershell
# Count items in WordPress export
.\Split-WordPressXML.ps1 -InputFile "your_wordpress_export.xml" -CountOnly

# Split into chunks of 50 posts
.\Split-WordPressXML.ps1 -InputFile "your_wordpress_export.xml" -ChunkSize 50
```

## 📋 Ghost Import Process

1. Run the tool to split your WordPress XML export
2. Log in to your Ghost admin dashboard
3. Go to Settings > Labs
4. Under "Import content", click "Select File"
5. Choose one of the split XML files
6. Wait for the import to complete
7. Repeat steps 4-6 for each XML file

## ⚠️ Troubleshooting

If you encounter issues with the import process:

- Try reducing the chunk size further (start with 50, then try 25 if needed)
- Make sure your XML file is valid and properly formatted
- Check if Ghost has specific requirements for import file format
- Verify that all necessary namespaces are preserved in the split files
- Import files in numerical order (chunk1, chunk2, etc.)

## 📝 Notes

- The tool preserves all XML headers and namespaces required for proper import
- Each chunk contains all necessary metadata from the original file
- The tool does not modify the content of your posts
- For large exports (3000+ posts), a chunk size of 50 is recommended

## 🔧 Technical Details

- The tool parses the WordPress XML using ElementTree
- It preserves the RSS structure and all WordPress namespaces
- Each chunk is a valid WordPress export file
- The web interface is built with Flask and Bootstrap

## 📄 License

MIT License

## 👤 Author

**Gunjan Jaswaal**

- Website: [gunjanjaswal.me](https://gunjanjaswal.me)
- Email: [hello@gunjanjaswal.me](mailto:hello@gunjanjaswal.me)

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/amazing-feature`)
3. Commit your Changes (`git commit -m 'Add some amazing feature'`)
4. Push to the Branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request
