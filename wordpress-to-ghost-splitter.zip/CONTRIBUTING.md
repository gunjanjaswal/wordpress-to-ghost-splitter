# Contributing to WordPress to Ghost XML Splitter

Thank you for considering contributing to the WordPress to Ghost XML Splitter! This document provides guidelines and instructions for contributing to this project.

## Code of Conduct

By participating in this project, you agree to maintain a respectful and inclusive environment for everyone.

## How Can I Contribute?

### Reporting Bugs

If you find a bug, please create an issue with the following information:
- A clear, descriptive title
- Steps to reproduce the issue
- Expected behavior vs. actual behavior
- Screenshots if applicable
- Any relevant details about your environment (OS, browser, etc.)

### Suggesting Enhancements

If you have ideas for enhancements, please create an issue with:
- A clear, descriptive title
- Detailed explanation of the proposed enhancement
- Any relevant examples or mockups

### Pull Requests

1. Fork the repository
2. Create a new branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run tests if applicable
5. Commit your changes (`git commit -m 'Add some amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

## Development Setup

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run the web application: `python app.py`

## Coding Guidelines

- Follow PEP 8 style guidelines for Python code
- Write clear, descriptive commit messages
- Include comments in your code when necessary
- Add tests for new features when possible

## Documentation

If you're adding new features or changing existing ones, please update the documentation accordingly.

## Questions?

If you have any questions about contributing, please feel free to contact the project maintainer:

- Gunjan Jaswaal
- Email: hello@gunjanjaswal.me
- Website: https://gunjanjaswal.me

Thank you for your contribution!
