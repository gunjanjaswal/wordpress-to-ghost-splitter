# WordPress to Ghost XML Splitter - Usage Guide

This document provides detailed instructions on how to use the WordPress to Ghost XML Splitter tool to migrate your WordPress content to Ghost.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Exporting WordPress Content](#exporting-wordpress-content)
3. [Using the Web Interface](#using-the-web-interface)
4. [Using the Command Line Tools](#using-the-command-line-tools)
5. [Importing into Ghost](#importing-into-ghost)
6. [Troubleshooting](#troubleshooting)
7. [FAQ](#faq)

## Prerequisites

Before using this tool, ensure you have:

- A WordPress XML export file
- Python 3.6 or higher (for the web interface or Python script)
- PowerShell (for Windows users who prefer the PowerShell script)
- Access to your Ghost admin panel

## Exporting WordPress Content

To export your WordPress content:

1. Log in to your WordPress admin dashboard
2. Go to **Tools** > **Export**
3. Select **All content** (or choose specific content types)
4. Click **Download Export File**
5. Save the XML file to your computer

## Using the Web Interface

The web interface is the easiest way to use the tool, especially for users who aren't comfortable with command line tools.

### Installation

```bash
# Clone the repository
git clone https://github.com/gunjanjaswaal/wordpress-to-ghost-splitter.git
cd wordpress-to-ghost-splitter

# Install dependencies
pip install -r requirements.txt

# Run the web application
python app.py
```

### Step-by-Step Usage

1. **Access the Web Interface**
   - Open your browser and navigate to http://127.0.0.1:5000

2. **Upload Your WordPress XML File**
   - Click the "Choose File" button
   - Select your WordPress XML export file
   - Click "Upload & Analyze"

3. **Review Content Analysis**
   - The tool will analyze your file and show you how many posts, pages, and attachments it contains
   - Based on the file size, it will recommend an appropriate chunk size

4. **Configure Splitting Options**
   - Set the number of items per chunk (recommended: 50 for large exports)
   - Select which content types to include (posts, pages, attachments)
   - Click "Split XML File"

5. **Download Split Files**
   - Once processing is complete, click "Download Split XML Files"
   - Extract the ZIP file to a folder on your computer

## Using the Command Line Tools

### Python Script

```bash
# Basic usage
python wp_xml_splitter.py your_wordpress_export.xml

# Count items without splitting
python wp_xml_splitter.py your_wordpress_export.xml -c

# Split into chunks of 50 posts
python wp_xml_splitter.py your_wordpress_export.xml -s 50

# Only include posts and pages
python wp_xml_splitter.py your_wordpress_export.xml -t post page

# Specify output directory
python wp_xml_splitter.py your_wordpress_export.xml -o my_output_directory
```

### PowerShell Script (Windows)

```powershell
# Basic usage
.\Split-WordPressXML.ps1 -InputFile "your_wordpress_export.xml"

# Count items without splitting
.\Split-WordPressXML.ps1 -InputFile "your_wordpress_export.xml" -CountOnly

# Split into chunks of 50 posts
.\Split-WordPressXML.ps1 -InputFile "your_wordpress_export.xml" -ChunkSize 50

# Specify output directory
.\Split-WordPressXML.ps1 -InputFile "your_wordpress_export.xml" -OutputDir "my_output_directory"
```

## Importing into Ghost

After splitting your WordPress XML export file, follow these steps to import the content into Ghost:

1. **Log in to Ghost Admin**
   - Access your Ghost admin dashboard

2. **Navigate to Import Tool**
   - Go to **Settings** > **Labs**
   - Scroll down to the **Import content** section

3. **Import Each File**
   - Click **Select File**
   - Choose the first split XML file (e.g., `your_wordpress_export_chunk1of10.xml`)
   - Wait for the import to complete
   - Repeat for each split file in numerical order

4. **Verify Content**
   - After importing all files, check that all your content appears correctly in Ghost
   - Verify posts, pages, images, and other content types as needed

## Troubleshooting

### Common Issues and Solutions

#### "Error loading XML file"

- **Cause**: The XML file may be corrupted or not properly formatted
- **Solution**: Verify that your WordPress export file is valid XML. Try re-exporting from WordPress.

#### "Import failed in Ghost"

- **Cause**: Ghost may have issues with certain content in the XML file
- **Solution**: Try reducing the chunk size further (e.g., 25 posts per chunk)

#### "Missing images after import"

- **Cause**: Ghost may not import all media files automatically
- **Solution**: You may need to manually upload some images or use a separate tool for media migration

#### "Python/Flask errors"

- **Cause**: Missing dependencies or configuration issues
- **Solution**: Ensure you've installed all requirements with `pip install -r requirements.txt`

### Getting Help

If you encounter issues not covered here:

1. Check the [GitHub Issues](https://github.com/gunjanjaswaal/wordpress-to-ghost-splitter/issues) to see if someone has reported the same problem
2. Create a new issue with detailed information about your problem
3. Contact the author at hello@gunjanjaswal.me

## FAQ

### How many posts should I include per chunk?

For most Ghost installations, 50-100 posts per chunk works well. If you have very large posts with many images, you might need to use smaller chunks (25-50).

### Does this tool modify my content?

No, the tool only splits your XML file into smaller chunks. It preserves all content, metadata, and structure exactly as it was in the original export.

### Will this tool migrate my WordPress theme?

No, this tool only helps migrate content (posts, pages, etc.). You'll need to set up your Ghost theme separately.

### Can I use this tool for other platforms besides Ghost?

This tool is specifically designed for WordPress to Ghost migration. It may not work correctly for other platforms.

### Is my data secure?

Yes, all processing happens locally on your machine. Your WordPress content is never sent to any external servers.
