#!/usr/bin/env python3
"""
WordPress to Ghost XML Splitter - Web Interface

A web application that helps users split large WordPress XML exports into smaller chunks
that can be imported into Ghost without hitting the "too many posts" error.

Author: Gunjan Jaswaal
Email: hello@gunjanjaswal.me
Website: https://gunjanjaswal.me
"""

import os
import sys
import shutil
import tempfile
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, session
from werkzeug.utils import secure_filename
import xml.etree.ElementTree as ET
import zipfile
import uuid

# Import the XML splitter functionality
from wp_xml_splitter import count_items, split_wordpress_xml

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['OUTPUT_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'output')
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max upload size

# Create necessary directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

# Add context processor to provide 'now' variable to all templates
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Register WordPress XML namespace
WP_NAMESPACE = {'wp': 'http://wordpress.org/export/1.2/'}

def allowed_file(filename):
    """Check if the uploaded file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'xml'}

def create_zip_file(directory, zip_filename):
    """Create a zip file from a directory."""
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, directory)
                zipf.write(file_path, arcname)
    return zip_filename

@app.route('/')
def index():
    """Render the main page."""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload and analysis."""
    if 'file' not in request.files:
        flash('No file part', 'error')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        # Generate a unique ID for this session
        session_id = str(uuid.uuid4())
        session['session_id'] = session_id
        
        # Create session directories
        session_upload_dir = os.path.join(app.config['UPLOAD_FOLDER'], session_id)
        session_output_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
        os.makedirs(session_upload_dir, exist_ok=True)
        os.makedirs(session_output_dir, exist_ok=True)
        
        # Save the uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(session_upload_dir, filename)
        file.save(filepath)
        session['filename'] = filename
        session['filepath'] = filepath
        
        # Count items in the XML file
        try:
            counts = count_items(filepath)
            if counts:
                session['counts'] = counts
                return redirect(url_for('analyze'))
            else:
                flash('Error analyzing the XML file. Please make sure it is a valid WordPress export file.', 'error')
                return redirect(url_for('index'))
        except Exception as e:
            flash(f'Error: {str(e)}', 'error')
            return redirect(url_for('index'))
    else:
        flash('Only XML files are allowed', 'error')
        return redirect(url_for('index'))

@app.route('/analyze')
def analyze():
    """Show analysis of the uploaded file."""
    if 'counts' not in session:
        flash('Please upload a file first', 'error')
        return redirect(url_for('index'))
    
    return render_template('analyze.html', 
                          counts=session['counts'], 
                          filename=session['filename'])

@app.route('/split', methods=['POST'])
def split():
    """Split the XML file into chunks."""
    if 'filepath' not in session:
        flash('Please upload a file first', 'error')
        return redirect(url_for('index'))
    
    try:
        chunk_size = int(request.form.get('chunk_size', 100))
        post_types = request.form.getlist('post_types')
        
        # If no post types are selected, use all
        if not post_types:
            post_types = None
        
        session_id = session.get('session_id')
        if not session_id:
            flash('Session error. Please try again.', 'error')
            return redirect(url_for('index'))
        
        session_output_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
        
        # Split the file
        success = split_wordpress_xml(
            session['filepath'], 
            session_output_dir, 
            chunk_size, 
            post_types
        )
        
        if success:
            # Create a zip file of the output
            zip_filename = f"{os.path.splitext(session['filename'])[0]}_split.zip"
            zip_path = os.path.join(app.config['OUTPUT_FOLDER'], zip_filename)
            create_zip_file(session_output_dir, zip_path)
            
            session['zip_filename'] = zip_filename
            flash('File successfully split!', 'success')
            return redirect(url_for('download'))
        else:
            flash('Error splitting the file. Please try again.', 'error')
            return redirect(url_for('analyze'))
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('analyze'))

@app.route('/download')
def download():
    """Show download page."""
    if 'zip_filename' not in session:
        flash('No files to download. Please split a file first.', 'error')
        return redirect(url_for('index'))
    
    return render_template('download.html', 
                          zip_filename=session['zip_filename'],
                          counts=session.get('counts', {}))

@app.route('/get_file/<filename>')
def get_file(filename):
    """Download the zip file."""
    session_id = session.get('session_id')
    if not session_id:
        flash('Session error. Please try again.', 'error')
        return redirect(url_for('index'))
    
    return send_from_directory(app.config['OUTPUT_FOLDER'], filename, as_attachment=True)

@app.route('/reset')
def reset():
    """Reset the session and start over."""
    # Clean up session files
    if 'session_id' in session:
        session_id = session['session_id']
        session_upload_dir = os.path.join(app.config['UPLOAD_FOLDER'], session_id)
        session_output_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
        
        try:
            if os.path.exists(session_upload_dir):
                shutil.rmtree(session_upload_dir)
            if os.path.exists(session_output_dir):
                shutil.rmtree(session_output_dir)
        except Exception as e:
            print(f"Error cleaning up: {str(e)}")
    
    # Clear session
    session.clear()
    
    flash('Ready to start a new conversion', 'info')
    return redirect(url_for('index'))

@app.errorhandler(413)
def request_entity_too_large(error):
    flash('File too large. Maximum size is 500MB.', 'error')
    return redirect(url_for('index')), 413

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
